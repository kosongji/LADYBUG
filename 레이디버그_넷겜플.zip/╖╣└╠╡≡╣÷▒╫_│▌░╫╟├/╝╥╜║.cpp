#include <windows.h>  // ������ ��� ���� 
#include <TCHAR.H>
#include <time.h>
#include <math.h>
#include <iostream>
#include <atlimage.h>

//sound h
#include <conio.h>
#include <fmod.h>

#define ITEM_TYPE 8
FMOD_SYSTEM *g_System;
FMOD_SOUND *g_Sound[8];
FMOD_CHANNEL *g_Channel[8];

/// <summary>
/// FMOD System INIT fucntion
/// </summary>

void Init()
{
	FMOD_System_Create(&g_System);
	FMOD_System_Init(g_System, 8, FMOD_INIT_NORMAL, NULL);

	FMOD_System_CreateSound(g_System, "�����2.mp3", FMOD_LOOP_NORMAL, 0, &g_Sound[0]);
	FMOD_System_CreateSound(g_System, "1.wav", FMOD_DEFAULT, 0, &g_Sound[1]);
	FMOD_System_CreateSound(g_System, "����2.wav", FMOD_DEFAULT, 0, &g_Sound[2]);
	FMOD_System_CreateSound(g_System, "6.wav", FMOD_DEFAULT, 0, &g_Sound[3]);
	FMOD_System_CreateSound(g_System, "8.wav", FMOD_DEFAULT, 0, &g_Sound[2]);
	FMOD_System_CreateSound(g_System, "10.wav", FMOD_DEFAULT, 0, &g_Sound[5]);
	FMOD_System_CreateSound(g_System, "�����1.mp3", FMOD_DEFAULT, 0, &g_Sound[6]);
	FMOD_System_CreateSound(g_System, "10gas.wav", FMOD_DEFAULT, 0, &g_Sound[7]);

	FMOD_System_PlaySound(g_System, FMOD_CHANNEL_FREE, g_Sound[0], 0, &g_Channel[0]);
}

/// FMOD System Release fucntion
void Release()
{
	FMOD_Sound_Release(g_Sound[1]);
	FMOD_System_Close(g_System);
	FMOD_System_Release(g_System);
}

#define CONSOLE 1
#define MONSTER 500
#define DEBUG 1

using namespace std;

//����̽� ���׽�Ʈ ���
HINSTANCE g_hInst;
LPCTSTR lpszClass = L"Window Class Name";

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASSEX WndClass;
	g_hInst = hInstance;
	WndClass.cbSize = sizeof(WndClass);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.lpszMenuName = NULL;
	WndClass.lpszClassName = lpszClass;
	WndClass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	RegisterClassEx(&WndClass);

	//if (CONSOLE)
	//{
	//	AllocConsole();
	//	freopen("CONOUT$", "wt", stdout);
	//}

	hWnd = CreateWindow(lpszClass, L"���̵� ����", WS_OVERLAPPEDWINDOW | WS_SYSMENU | WS_THICKFRAME, 0, 0, 500, 800, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	while (GetMessage(&Message, 0, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return Message.wParam;
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hDC, memdc;               //����̽� ���ؽ�Ʈ�� ������ ���� HDC�� 
	PAINTSTRUCT ps;            //��¿���(����)�� ���� ������ ������ ���� PS����.
	static HBITMAP hBit, oldBit;

	HPEN hPen, oldPen;
	HBRUSH hBrush, oldBrush;
	HFONT myFont, oldFont;


	switch (iMessage)
	{
	case WM_CREATE:

		Init();
		//FMOD_Channel_IsPlaying(g_Channel[0], &IsPlaying);

		srand((unsigned)time(NULL));
		SetTimer(hWnd, 1, 17, NULL);

		break;
	case WM_CHAR:
		switch (wParam)
		{

		case '1':
			break;

		case '6':
			break;
		case '8':
			break;

		case '0':
			break;

		case '2':
			break;

		case 'p':
		case 'P':

			break;

		}
		InvalidateRgn(hWnd, NULL, FALSE);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_SPACE:
			break;
		}
		InvalidateRgn(hWnd, NULL, FALSE);
		break;
	case WM_LBUTTONDOWN:

		break;
	case WM_LBUTTONUP:


		InvalidateRgn(hWnd, NULL, FALSE);
		break;
	case WM_MOUSEMOVE:



		break;
	case WM_TIMER:


		InvalidateRgn(hWnd, NULL, FALSE);
		break;
	case WM_PAINT:
		hDC = BeginPaint(hWnd, &ps);
		memdc = CreateCompatibleDC(hDC);

		hBit = CreateCompatibleBitmap(hDC, 1000, 800);
		SelectObject(memdc, hBit);


		BitBlt(hDC, 0, 0, 500, 800, memdc, 0, 0, SRCCOPY);

		DeleteObject(hBit);
		DeleteDC(memdc);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		Release();
		PostQuitMessage(0);
		break;
	}

	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
